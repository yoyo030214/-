#!/bin/bash

echo "=== 开始部署农业应用后端 ==="

# 检查是否以root权限运行
if [ "$EUID" -ne 0 ]; then 
  echo "请使用root权限运行此脚本"
  exit 1
fi

# 检查Docker是否安装
if ! command -v docker &> /dev/null; then
    echo "正在安装Docker..."
    curl -fsSL https://get.docker.com -o get-docker.sh
    sh get-docker.sh
    rm get-docker.sh
fi

# 检查Docker Compose是否安装
if ! command -v docker-compose &> /dev/null; then
    echo "正在安装Docker Compose..."
    curl -L "https://github.com/docker/compose/releases/download/v2.24.1/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
    chmod +x /usr/local/bin/docker-compose
fi

# 创建应用目录
APP_DIR="/opt/agricultural-app"
mkdir -p $APP_DIR
cd $APP_DIR

# 复制项目文件
echo "正在复制项目文件..."
cp -r /tmp/docker-backend/* .

# 设置权限
chmod +x docker-start.sh
chmod +x start.sh

# 配置防火墙
echo "正在配置防火墙..."
if command -v ufw &> /dev/null; then
    ufw allow 5000/tcp
    ufw allow 3307/tcp
elif command -v firewall-cmd &> /dev/null; then
    firewall-cmd --permanent --add-port=5000/tcp
    firewall-cmd --permanent --add-port=3307/tcp
    firewall-cmd --reload
fi

# 启动服务
echo "正在启动服务..."
./docker-start.sh

# 等待服务启动
echo "等待服务启动..."
sleep 30

# 检查服务状态
echo "检查服务状态..."
docker ps

echo "=== 部署完成 ==="
echo "API服务地址: http://服务器IP:5000"
echo "数据库端口: 3307"
echo "数据库用户名: root"
echo "数据库密码: lol110606YY"
echo "数据库名: agricultural_app" 